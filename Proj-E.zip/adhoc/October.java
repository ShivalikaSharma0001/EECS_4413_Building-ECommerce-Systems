package adhoc;

import java.io.IOException;
import java.io.Writer;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import model.Engine;
import model.StudentBean;


//Block the Ride service completely by serving a page that informs the user that this service is not available with a link to the Dashboard.
//Block any request for sorting in the SIS service. If any sorting is requested then serve a page that informs the user that this sorting 
//is not available with a link to the Dashboard.

/**
 * Servlet Filter implementation class October
 */

@WebFilter({ "/October" })
// "/Ride.do", "/Sis.do"
public class October implements Filter 
{

    /**
     * Default constructor. 
     */
    public October()
    {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy()
	{
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		HttpServletRequest hreq = (HttpServletRequest) request;
		
		if (hreq.getServletPath().contains("Ride.do"))
		{
			response.setContentType("text/html");
			Writer out = response.getWriter();
			String html = "<html><body>";
			html += "<p>Feature not available ... <a href='Dash.do'>Back to Dashboard</a></p>";
			html += "</body></html>";
			out.write(html);
		}	
		
		else if (hreq.getServletPath().contains("Sis.do"))
		{
			if ((hreq.getParameter("sortBy") != null) && (!"NONE".equals(hreq.getParameter("sortBy"))))
			{
				response.setContentType("text/html");
				Writer out = response.getWriter();
				String html = "<html><body>";
				html += "<p>Feature not available ... <a href='Dash.do'>Back to Dashboard</a></p>";
				html += "</body></html>";
				out.write(html);
			}
			else
			{
				chain.doFilter(hreq, response);
			}
		}		
		
		else
		{
			chain.doFilter(hreq, response);
		}

	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException 
	{
		// TODO Auto-generated method stub
	}

}


