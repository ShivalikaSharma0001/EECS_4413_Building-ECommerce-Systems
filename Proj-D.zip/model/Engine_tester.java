package model;

public class Engine_tester
{

	public static void main(String[] args) throws Exception
	{
		Engine engine = Engine.getInstance();
		//engine.doDrone("400 Keele", "100 Markham");
		///engine.doRide("400 Keele", "100 Markham");
		
		StudentDAO sd = new StudentDAO();
		System.out.println(sd.retrieve("A", "5", "SURNAME"));

	}

}
