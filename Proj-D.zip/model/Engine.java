package model;

import java.io.File;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class Engine 
{
	private static Engine instance = null;
	private final String key = "AIzaSyCdmKUd4NpJLKrv4CLNpsTR3jIB3HWBEzM";
	private final String addressDrone = "https://maps.googleapis.com/maps/api/geocode/xml?key="+key;
	private final String addressRide = "https://maps.googleapis.com/maps/api/distancematrix/xml?key="+key;
	private final double radianConst = Math.PI/180.0;
	private final double cost = 50; // 50 cents per minute
	private final double speed = 150;
	private StudentDAO sd; 
	
	private Engine() 
	{
		sd = new StudentDAO();
	}
		
	public static Engine getInstance() 
	{
		if (instance == null)
		{	
			instance = new Engine();
		}
		return instance;
	}
	
	public BigInteger doPrime(String min, String max) throws Exception
	{
		BigInteger largerThan = new BigInteger(min);
		BigInteger notLargerThan = new BigInteger(max);
		BigInteger nextPrime = largerThan.nextProbablePrime();
		
		if (nextPrime.compareTo(notLargerThan) == 1)
		{
			throw new Exception("No more primes in range.");
		}
		else
		{
			return nextPrime;
		}
	}
	
	public HashMap<Integer,String> doPrimeAll(String min, String max) throws Exception
	{
		BigInteger largerThan = new BigInteger(min);
		BigInteger notLargerThan = new BigInteger(max);
		BigInteger nextPrime = largerThan.nextProbablePrime();
		HashMap<Integer,String> hm=new HashMap<Integer,String>();  
		int index = 1;
		
		while (notLargerThan.compareTo(nextPrime) == 1)
		{
			BigInteger np = nextPrime;
			hm.put(index, np + "");  
			index = index + 1;
			nextPrime = np.nextProbablePrime();
		}
		

		if (isNumeric(min) && isNumeric(max))
		{
			return hm;
		}
		else
		{
			throw new Exception("Invalid Entries!");
		}
	}
	
	public static boolean isNumeric(String str)
	{
	    for (char c : str.toCharArray())
	    {
	        if (!Character.isDigit(c)) return false;
	    }
	    return true;
	}
	
	public double doGps(String lat1, String lon1, String lat2, String lon2) throws Exception
	{
		double t1 = Double.parseDouble(lat1)*radianConst;
		double n1 = Double.parseDouble(lon1)*radianConst;
		double t2 = Double.parseDouble(lat2)*radianConst;
		double n2 = Double.parseDouble(lon2)*radianConst;
		
		// Y = cos(t1) * cos(t2)
		double y = Math.cos(t1) * Math.cos(t2);
		
		// X = sin2[(t2-t1)/2] + Y * sin2[(n2-n1)/2]
		double x = Math.pow(Math.sin((t2-t1)/2), 2) + y*(Math.pow(Math.sin((n2-n1)/2), 2));
		
		// 12742 * atan2[sqrt(X), sqrt(1-X)]
		double constant = 12742;
		double result = constant*Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
		
		return result;
	}
	
	// key - AIzaSyCdmKUd4NpJLKrv4CLNpsTR3jIB3HWBEzM
	public double doDrone(String from, String dest) throws Exception
	{
		from = from.replace(' ', '+');
		dest = dest.replace(' ', '+');
		
		String fromArr[] = this.doDroneHelper(from);
		String destArr[] = this.doDroneHelper(dest);
		
		double distance = this.doGps(fromArr[0], fromArr[1], destArr[0], destArr[1]);
		double time = distance / speed;
		time = time*60;
		
		return time;
	}
	
	public String[] doDroneHelper(String str) throws Exception
	{	
		String url = addressDrone+"&address="+str;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(new URL(url).openStream());

		Element ele= (Element) doc.getElementsByTagName("location").item(0);
		String lat = ele.getElementsByTagName("lat").item(0).getTextContent();
		String lng = ele.getElementsByTagName("lng").item(0).getTextContent();
		
		String[] arr = new String[2];
		arr[0] = lat;
		arr[1] = lng;
		
		return arr;
	}

	// https://maps.googleapis.com/maps/api/distancematrix/xml?origins=4700+Keele+St,+Toronto,+ON+M3J+1P3&destinations=40+Maisonneuve+Blvd+Brampton,+ON+L6P+1Z4&departure_time=now&key=AIzaSyCdmKUd4NpJLKrv4CLNpsTR3jIB3HWBEzM
	// key - AIzaSyCdmKUd4NpJLKrv4CLNpsTR3jIB3HWBEzM 
	public double doRide(String from, String dest) throws Exception
	{
		from = from.replace(' ', '+');
		dest = dest.replace(' ', '+');
		
		String url = addressRide+"&origins="+from+"&destinations="+dest+"&departure_time=now";
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(new URL(url).openStream());
		
		Element ele= (Element) doc.getElementsByTagName("duration_in_traffic").item(0);
		String minsStr = ele.getElementsByTagName("value").item(0).getTextContent();
		//System.out.println("Mins is: "+mins);
		double mins = Double.parseDouble(minsStr)/60;
		double totalCost = mins*cost;
		
		return totalCost/100;
	}
	
	public List<StudentBean> doSis(String prefix, String minGpa, String NONE) throws Exception
	{
		return sd.retrieve(prefix, minGpa, NONE);
	}
}


//boolean isMinInt = false;
//boolean isMaxInt = false;


//int minInt = Integer.parseInt(min);		
//int maxInt = Integer.parseInt(max);		


//if ((minInt != (int)minInt) || maxInt != (int)maxInt)
//{
//	System.out.println("Am here");
//	throw new Exception("Invalid Entries!");
//}
