package model;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO
{
	public static final String DB_URL = "jdbc:derby://localhost:64413/EECS;user=student;password=secret";
	
	public List<StudentBean> retrieve(String prefix, String minGpa,String option) throws Exception
	{
		Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
		Connection con = DriverManager.getConnection(DB_URL);
		Statement s = con.createStatement();
		s.executeUpdate("set schema roumani");
		double gpa = Double.valueOf(minGpa);
		
		String query = "";
	
		if (option.equals("NONE"))
		{
			query = "select SURNAME, GIVENNAME, MAJOR, COURSES, GPA from SIS where SURNAME like '"+prefix+"%' and GPA > "+gpa;
		}
		else
		{
			System.out.print("Options is: "+option);
			query = "select SURNAME, GIVENNAME, MAJOR, COURSES, GPA from SIS where SURNAME like '"+prefix+"%' and GPA > "+gpa+" order by "+option;
		}
		ResultSet r = s.executeQuery(query);
		
		List<StudentBean> sbList = new ArrayList<>();
		while (r.next())
		{
			String surname = r.getString("SURNAME");
        	String givenname = r.getString("GIVENNAME");
        	String name = surname+", "+givenname;
        	String major = r.getString("MAJOR");
        	int courses = r.getInt("COURSES");
        	double gpaF = r.getDouble("GPA");
        	
        	//System.out.format("%s, %s, %d, %f\n", name, major, courses, gpaF);
        	StudentBean sb = new StudentBean();
        	sb.setName(name);
        	sb.setMajor(major);
        	sb.setCourses(courses);
        	sb.setGpa(gpaF);
        	sbList.add(sb);
		}
		
		/*for(StudentBean sl : sbList) {
            System.out.println(sl.getName());
        }*/
		
		r.close(); 
		s.close(); 
		con.close();
		return sbList;  
	}
	
	
		
	
	
}

/*
 * Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
		  Connection con = DriverManager.getConnection(DB_URL);
		  Statement s = con.createStatement();
		  s.executeUpdate("set schema roumani");
		  String query = "select Name, Price from ITEM where number = '"+itemNo+"'";
				  //SQL query to obtain the NAME and PRICE of an item whose number is itemNo in a table ITEM
		  ResultSet r = s.executeQuery(query);
		  String result = "";
		  if (r.next())
		  {
		  	result = "$" + r.getDouble("PRICE") + " - " + r.getString("NAME");
		  }
		  else
		  {
		  	throw new Exception(itemNo + " not found!");
		  }
		  r.close(); 
		  s.close(); 
		  con.close();
		  
		  return result;*/
 