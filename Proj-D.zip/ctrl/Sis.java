package ctrl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Engine;
import model.StudentBean;

@WebServlet("/Sis.do")
public class Sis extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		if (request.getParameter("calc") != null)
		{
			Engine engine = Engine.getInstance();
			String prefix = request.getParameter("prefix");
			String minGpa = request.getParameter("minGpa");
			String NONE = request.getParameter("sortBy");
			String tb = request.getParameter("tb");
			request.setAttribute("prefix", prefix);
			request.setAttribute("minGpa", minGpa);
			request.setAttribute("NONE", NONE);
			request.setAttribute("tb", tb);
			
			try
			{
				List<StudentBean> result = engine.doSis(prefix, minGpa, NONE);
				request.setAttribute("result",  result);
			} 
			catch (Exception e)
			{
				request.setAttribute("error", e.getMessage());
			}
		}
		//System.out.println(request.getAttribute("result"));
		this.getServletContext().getRequestDispatcher("/Sis.jspx").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}

}
