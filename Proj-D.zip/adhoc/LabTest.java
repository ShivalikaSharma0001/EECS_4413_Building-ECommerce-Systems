package adhoc;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.ResponseWrapper;

/**
 * Servlet Filter implementation class LabTest
 */
@WebFilter({"/LabTest","/Sis.do"})
public class LabTest implements Filter {

    /**
     * Default constructor. 
     */
    public LabTest() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
        HttpServletRequest hreq = (HttpServletRequest) request;
		
		if (hreq.getServletPath().contains("Sis.do"))
		{
			String value = hreq.getParameter("tb");
			int valueInt = Integer.parseInt(value);	
			if ((hreq.getParameter("tb") == null) || (valueInt < 0) || (valueInt > 9))
			{
				chain.doFilter(hreq, response);
			}
			else if ((hreq.getParameter("tb") != null) && (valueInt >= 0) || (valueInt <= 9))
			{
//				HttpServletResponse hres = (HttpServletResponse) response;
//				
//				
//				chain.doFilter(hreq, response);
				// change the gpa behaviour here
			}
			else
			{
				chain.doFilter(hreq, response);
			}
		}	
		else
		{
			chain.doFilter(hreq, response);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
